$(document).ready(function() {

    // $('#comprar-ahora').click(function() {
    //   $('#accion').val('comprar-ahora');
    //   $('#formulario-ficha').submit();
    // });

    // $('#agregar-al-carrito').click(function() {
    //   $('#accion').val('agregar-al-carrito');
    //   $('#formulario-ficha').submit();
    // });

});